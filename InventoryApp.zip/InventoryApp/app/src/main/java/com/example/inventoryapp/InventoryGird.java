package com.example.inventoryapp;

package com.example.android.items.data;

import android.net.Uri;
import android.content.ContentResolver;
import android.provider.BaseColumns;

/**
 * API Contract for the Items app.
 */
public final class ItemContract {

    private ITems() {}

    public static final String CONTENT_AUTHORITY = "com.example.android.items";
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);
    public static final String PATH_ITEMS = "items";


    public static final class ItemEntry implements BaseColumns {

        /** Access to items*/
        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_ITEMS);
        public static final String CONTENT_LIST_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_ITEMS;
        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_ITEMS;

        /** Name of items in the  table*/
        public final static String TABLE_NAME = "items";
        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_ITEM_NAME ="name";

        public final static String COLUMN_ITEM_TYPE = "type";

        public final static String COLUMN_ITEM_PRICE = "price";


        public final static String COLUMN_ITEM_QUANTITY = "quantity";

        public final static String COLUMN_ITEM_IMAGE = "image";
/**Values of items*/
        public static final int TYPE_UNKNOWN = 0;
        public static final int TYPE_FOOD = 1;
        public static final int TYPE_CLOTHING = 2;



        public static boolean isValidType(int type) {
            if (type == TYPE_UNKNOWN || type == TYPE_FOOD || type == TYPE_CLOTHING) {
                return true;
            }
            return false;
        }
    }
}

