package com.example.chrisrodgersapp1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText nameType;
    private TextView textHi;
    private Button SayHi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //get instances of NameText, textGreeting, and Say Hello
        nameType = (EditText) findViewById(R.id.nameType);
        textHi = (TextView) findViewById(R.id.textHello);
        SayHi = (Button) findViewById(R.id.buttonSayHello);

//Disable the Hello button So that a name must be included
        SayHi.setEnabled(false);

//Attach text change Listnener for nameText

        nameType.addTextChangedListener(new TextWatcher() {

                                            @Override
                                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                                            }

                                            @Override
                                            public void onTextChanged(CharSequence s, int start, int count, int after) {
                                            }

                                            @Override // make the text able to be edited
                                            public void afterTextChanged(Editable s) {
                                                if (s.toString().equals("")) {
                                                    SayHi.setEnabled(false);
                                                }// check if nameText contains a string
                                                else {
                                                    SayHi.setEnabled(true);

                                                }
                                            }
                                        }
        );
    }
        public void SayHi (View v){
            String name = nameType.getText().toString();
            if (name.equals("")) {
                textHi.setText("Whats your name?");
            } else {
                textHi.setText("How are you, " + name + ".");
            }
        }
    }
